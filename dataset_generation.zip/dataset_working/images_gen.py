import numpy as np
import cv2
from random import randint
# Create a black image


def Circle():
    for i in range(1,11):
        img = np.ones((128, 128, 3), np.uint8) * 255
        cv2.circle(img, (64, 64), randint(25, 60), (0, 0, 0), 1)
        cv2.imwrite('./circle/'+str(i)+'.png',img)


#Circle()

def Rectangle():
    for i in range(1,11):
        img = np.ones((128, 128, 3), np.uint8) * 255
        cv2.rectangle(img,(randint(1, 60),randint(1, 60)),(randint(64, 125),randint(64, 125)),(0, 0, 0), 1)
        cv2.imwrite('./rect/'+str(i)+'.png',img)


#Rectangle()

def Square():
    for i in range(1,11):
        img = np.ones((128, 128, 3), np.uint8) * 255
        size = randint(40,60)
        x = randint(30, 60)
        y = randint(30, 60)
        cv2.rectangle(img,(x, y),(x+size,y+size),(0, 0, 0), 1)
        cv2.imwrite('./square/'+str(i)+'.png',img)


#Square()

def Ellipse():
    for i in range(1,11):
        img = np.ones((128, 128, 3), np.uint8) * 255
        size = randint(40,60)
        x = randint(30, 60)
        y = randint(30, 60)
        cv2.ellipse(img, (64,64), (randint(40,64), randint(15,25)), randint(0,90), 0, 360, (0, 0, 0))
        cv2.imwrite('./ellipse/'+str(i)+'.png',img)

#Ellipse()


def Triangle():
    for i in range(1,11):
        img = np.ones((128, 128, 3), np.uint8) * 255
        pt1 = (randint(30,60), randint(30,60))
        pt2 = (randint(30,60), randint(90,120))
        pt3 = (randint(90,120), randint(90,120))
        triangle_cnt = np.array([pt1, pt2, pt3])
        cv2.drawContours(img, [triangle_cnt], 0, (0, 0, 0), 1)
        cv2.imwrite('./triangle/'+str(i)+'.png',img)

Triangle()