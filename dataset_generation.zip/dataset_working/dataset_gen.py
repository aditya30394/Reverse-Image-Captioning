import os
import numpy as np
import cv2

path = './'
objects = [name for name in os.listdir(path) if os.path.isdir(name)]
print(objects)

if '.idea' in objects:
	objects.remove('.idea')

if 'data' in objects:
	objects.remove('data')

"""
objects.remove('percentage')
objects.remove('omega')
objects.remove('copyright')
objects.remove('beta')
objects.remove('ampersand')
objects.remove('sigma')
objects.remove('right arrow')
objects.remove('down arrow')
objects.remove('octagon')
objects.remove('minus')
objects.remove('euro')
objects.remove('cube')
objects.remove('up arrow')
objects.remove('thunder')
objects.remove('ellipse')
objects.remove('plus')
objects.remove('circle')
objects.remove('question mark')
objects.remove('square braces')
objects.remove('curly braces')
objects.remove('left arrow')
objects.remove('semicolon')
objects.remove('heptagon')
objects.remove('less than')
objects.remove('infinity')
objects.remove('rectangle')
objects.remove('heart')
objects.remove('root')
objects.remove('set union')
objects.remove('pie')
objects.remove('hashtag')
objects.remove('double horizontal arrow')
objects.remove('square')
objects.remove('cloud')
objects.remove('pound')
objects.remove('asterisk')
objects.remove('dollar')
objects.remove('pentagon')
objects.remove('star')
objects.remove('multiplication')
objects.remove('double vertical arrow')
objects.remove('phi')
objects.remove('cent')
objects.remove('hexagon')
objects.remove('equality')
objects.remove('alpha')
objects.remove('lambda')
objects.remove('triangle')
objects.remove('set intersection')
objects.remove('greater than')
objects.remove('exclamation mark')
"""



print('Length is : ', len(objects))

dataset_count=1
f = open('caption.txt', 'wb')

for A in objects:
    for B in objects:
        imagesA = [path + A + '/' + img for img in os.listdir(path + A + '/')]
        imagesB = [path + B + '/' + img for img in os.listdir(path + B + '/')]
        print('Started Pair : ', A, B)
        for imgA in imagesA:
            for imgB in imagesB:
                img1 = cv2.imread(imgA, cv2.IMREAD_UNCHANGED )
                img2 = cv2.imread(imgB, cv2.IMREAD_UNCHANGED )
                horizontal = np.concatenate((img1, img2), axis=1)
                horizontal = cv2.resize(horizontal, (256,256))
                cv2.imwrite('./data/' + str(dataset_count) + '.png', horizontal)
                f.write('%d.png,%s on the left and %s on the right\n' % (dataset_count, A, B))
                f.write('%d.png,%s on the right and %s on the left\n' % (dataset_count, B, A))
                f.write('%d.png,%s to the left of %s\n' % (dataset_count, A, B))
                f.write('%d.png,%s to the right of %s\n' % (dataset_count, B, A))
                dataset_count = dataset_count + 1
                vertical = np.concatenate((img1, img2), axis=0)
                vertical = cv2.resize(vertical, (256, 256))
                cv2.imwrite('./data/' + str(dataset_count) + '.png', vertical)
                f.write('%d.png,%s on the top and %s on the bottom\n' % (dataset_count, A, B))
                f.write('%d.png,%s on the bottom and %s on the top\n' % (dataset_count, B, A))
                f.write('%d.png,%s on top of %s\n' % (dataset_count, A, B))
                f.write('%d.png,%s is below %s\n' % (dataset_count, B, A))
                dataset_count = dataset_count + 1
		
		print('Complete Pair : ', A, B)

f.close()

"""
# PRE PROCESSING - Removing the transparent background                
for A in objects:
    imagesA = [path + A + '/' + img for img in os.listdir(path + A + '/')]
    print(A, 'started')
    for imgA in imagesA:
        img1 = cv2.imread(imgA, cv2.IMREAD_UNCHANGED )
        alpha_channel = img1[:, :, 3]
        _, mask = cv2.threshold(alpha_channel, 254, 255, cv2.THRESH_BINARY)
        color = img1[:, :, :3]
        img1 = cv2.bitwise_not(cv2.bitwise_not(color, mask=mask))
        cv2.imwrite(imgA,img1)
    print(A, 'completed')    
        
"""
